export function DivAccent () {
  return (
    <div className='flex w-full border border-[var(--color-accent-dark)]' />
  )
}