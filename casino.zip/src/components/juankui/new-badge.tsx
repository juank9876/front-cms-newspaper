export function NewBadge() {
    return (
        <span className="not-italic inline-block bg-red-600  text-white px-2 py-1 text-xs font-bold rounded mr-3">
            NEW
        </span>
    )
}