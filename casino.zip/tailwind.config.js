// tailwind.config.js
module.exports = {
  darkMode: 'class', // o 'media' si usas preferencia del sistema
  // ...
};